import os
import numpy as np

from double_pendulum.controller.trajectory_following.feed_forward import (
    FeedForwardController,
)
from double_pendulum.experiments.hardware_control_loop_tmotors import run_experiment
from double_pendulum.model.symbolic_plant import SymbolicDoublePendulum
from double_pendulum.model.model_parameters import model_parameters


design = "design_C.1"
torque_limit = [0.0, 0.0]

# trajectory
dt = 0.005
t_final = 10.0
N = int(t_final / dt)
T_des = np.linspace(0, t_final, N + 1)
u1 = np.zeros(N + 1)
u2 = np.zeros(N + 1)
U_des = np.array([u1, u2]).T

# measurement filter
meas_noise_cut = 0.0
meas_noise_vfilter = "None"
filter_kwargs = {"lowpass_alpha": [1.0, 1.0, 0.2, 0.2]}

# controller
controller = FeedForwardController(
    T=T_des, U=U_des, torque_limit=[0.0, 0.0], num_break=40
)

controller.set_filter_args(
    filt=meas_noise_vfilter, velocity_cut=meas_noise_cut, filter_kwargs=filter_kwargs
)

controller.init()

run_experiment(
    controller=controller,
    dt=dt,
    t_final=t_final,
    can_port="can0",
    motor_ids=[1, 2],
    tau_limit=torque_limit,
    save_dir=os.path.join("data", design, "double-pendulum/donothing"),
)
