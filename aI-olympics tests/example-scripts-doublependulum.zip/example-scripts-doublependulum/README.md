# Hardware Experiments

## Can interface

The PC communicates with the motors via can. For this the can0 interface must
be brought up with

    . setup_caninterface.sh

You can check if the can interface it actually UP with 

    ifconfig

It should show status UP. If there is a problem with enabling the motors it is
most likely to a interupted can connection.

# Example scripts

This folder contains a few scripts to demonstrate and verify the functionality
of the hardware.

## donothing.py

This script sends only zero commands to the motors. It is useful to test the
connection and the data recording.

## fully_actuated_swingup.py

This script performs a swingup with a PD controller for a precomputed
trajectory.  Both motors are used.

## pendubot_swingup.py

This script performs a swingup with a TVLQR controller for a precomputed
trajectory. Only the shoulder motor is used by the controller. Friction
compensation is enabled on both motors.

Note: This swingup does not have a 100% success rate and may fail sometimes.

## acrobot_swingup.py

This script performs a swingup with a TVLQR controller for a precomputed
trajectory. Only the elbow motor is used by the controller. Friction
compensation is enabled on both motors.

Note: This swingup does not have a 100% success rate and may fail sometimes.

# Data

During the experiment all data is recorded and stored. This contains

    - the position, velocity, torque data (trajectory.csv)
    - a combined plot of this data (combiplot.pdf)
    - individual plots (elbow_swingup_pos.pdf, ...)
    - a video of the experiment (video.avi)

Note: At the end of the experiment the video recording is terminated forcefully
which prints a FATAL ERROR to the terminal. The recording is not affected by
this and the error can be ignored.

# Safety

If the motion of the double pendulum exceeds the limits of

    - +- 360° for the angles of the links
    - +- 20 rad/s for the angular velocities

the motion is automatically stopped and the experiment ends.
Additionally, there is a supervisor observing the experiment who may push the
emergency button to interupt dangerous behaviour of the system.
